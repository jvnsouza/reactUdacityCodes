export const primary = '#98C682';
export const primaryBlack = '#68984D';
export const success = '#388E3C';
export const danger = '#D32F2F';
